# Redturtle Interior Design

This is my first webpage practise what I made for sitebuilding lesson of my IT school.

If type [https://redturtle42.github.io](https://redturtle42.github.io/) you can see a live preview of my page. 

This is a copy of https://github.com/Redturtle42/Interior-Design repository.
### Used technologies
* HTML5
* CSS3
* JS

**Enjoy it!**
